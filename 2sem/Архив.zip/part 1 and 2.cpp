#include <iostream>
#include <fstream>
#include <stddef.h>

using namespace std;

template <typename Type>
class St {
    struct Node {
        Type d;
        Node* next;
    };

    Node* Fr;

    int count;
public:
    St() : count(0), Fr(nullptr) {}
    Type pop() {
        if (!Empt()) {
            --count;
            Type out = Fr->d;
            Node* temp = Fr->next;
            delete Fr;
            Fr = temp;
            return out;
        }
        return 0;
    }
    const Type& top() {
        if (!Empt())
            return Fr->d;
        return (int)NULL;
    }
    bool Empt() {
        return Fr == nullptr;
    }
    void push(const Type& value) {
            count++;
            if (Empt())
            {
                Fr = new Node;
                Fr->d = value;
                Fr->next = nullptr;
            }
            else
            {
                Node* temp = new Node;
                temp->d = value;
                temp->next = Fr;
                Fr = temp;
            }
    }
    ~St()
    {
        while (!Empt())
            pop();
    }
};

int main()
{
    St<int> A, St;
    ifstream fin("main.txt");

    int temp;
    while (!fin.eof())
    {
        fin >> temp;
        A.push(temp);
    }

    fin.close();
    while (!A.Empt())
        St.push(A.pop());

    ofstream
        even("even.txt"),
        odd("odd.txt");
    while (!St.Empt())
        if (St.top() % 2 == 0)    even << St.pop() << " ";
                        else    odd << St.pop() << " ";
    even.close();
    odd.close();
    return 0;
}

#include <iostream>
#include <list>
using namespace std;

int main()
{
	int n;
	list<int> li;
	while (cin.peek() != '\n') {
		cin >> n;
		li.push_back(n);
	}
	list<int>::iterator END = li.end();
	END--;
	int count;
	for (list<int>::iterator it = li.begin(); it != END; ++it)
	{
		if (*it > 99 && *it < 1000 && *it % 15 == 0 && *it % 30 != 0) count++;
	}
	cout << count;
	return 0;
}
#include <iostream>
#include <iterator>
#include <vector>

using namespace std;

template <typename Iterator>
double average(Iterator f, Iterator l)
{
    int n = 0;
    double sum = 0;
    
    while(f != l) { 
        sum += *f++;
        ++n;
    }
   
    return sum/n;
}
 
int main() {
	int n;
	vector<int> v;
	while (cin.peek() != '\n') {
		cin >> n;
		v.push_back(n);
	}
	vector<int>::iterator END = v.end();
	END--;
	cout << average(v.begin(), v.end());
	return 0;
}
